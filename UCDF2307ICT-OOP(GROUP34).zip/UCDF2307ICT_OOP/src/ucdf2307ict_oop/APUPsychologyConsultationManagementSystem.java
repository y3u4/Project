
package ucdf2307ict_oop;

import java.util.Scanner;

public class APUPsychologyConsultationManagementSystem {
    public static void main(String[] args) {
        
    }
    
}
